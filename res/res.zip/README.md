# osu-SkinSetList-ja
osu!のスキンセットリストを日本語で表記し,解説を加えたページ
